function[output] = vec(input)

output = input(:);